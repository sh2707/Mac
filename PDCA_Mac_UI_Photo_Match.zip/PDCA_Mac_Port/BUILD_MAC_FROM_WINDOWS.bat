@echo off
setlocal
where dotnet >nul 2>nul || (echo .NET 8 SDK is required. Install it on this Windows PC first.& exit /b 1)
echo Restoring NuGet packages. First build needs internet access on Windows.
dotnet restore PDCA.Mac.csproj || exit /b 1
echo Publishing Apple Silicon build (M-series Mac mini)...
dotnet publish PDCA.Mac.csproj -c Release -r osx-arm64 --self-contained true -p:PublishSingleFile=false -o publish\osx-arm64 || exit /b 1
echo Publishing Intel Mac build...
dotnet publish PDCA.Mac.csproj -c Release -r osx-x64 --self-contained true -p:PublishSingleFile=false -o publish\osx-x64 || exit /b 1
echo Done. Copy the matching publish folder to the Mac. Run the executable from Terminal initially.
echo IMPORTANT: This is a migration starter; verify all flows before production use.
endlocal
