using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Interactivity;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Net.Sockets;
using System.Net;

namespace PDCAMac;
public sealed class MainWindow : Window
{
    readonly TextBox url = new() { Text = "", Watermark = "Barcode query URL (use {PANEL_SN})" };
    readonly TextBox panel = new() { Watermark = "Panel SN" };
    readonly ComboBox method = new() { ItemsSource = new[] { "GET", "POST" }, SelectedIndex = 0, Width = 100 };
    readonly TextBox ip = new() { Text = "127.0.0.1", Width = 180 };
    readonly TextBox port = new() { Text = "9000", Width = 90 };
    readonly TextBox status = new() { IsReadOnly = true, Height = 70, TextWrapping = TextWrapping.Wrap };
    readonly TextBox raw = new() { IsReadOnly = true, Height = 90, TextWrapping = TextWrapping.Wrap };
    readonly TextBox[] data = Enumerable.Range(0, 8).Select(_ => new TextBox { Watermark = "Barcode data", MinWidth = 180 }).ToArray();
    readonly TextBox[] responses = Enumerable.Range(0, 8).Select(_ => new TextBox { IsReadOnly = true, Watermark = "Server response", MinWidth = 180 }).ToArray();
    readonly string templatePath = Path.Combine(AppContext.BaseDirectory, "Templates", "pdca_template.txt");
    readonly string configPath = Path.Combine(AppContext.BaseDirectory, "Config", "server.txt");
    readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(10) };
    public MainWindow()
    {
        Title = "QUERY DATA TO PDCA SENDER"; Width = 1317; Height = 655; MinWidth = 1100; MinHeight = 600;
        Background = Brush.Parse("#10111B"); Foreground = Brushes.White;
        var root = new StackPanel { Margin = new Thickness(8), Spacing = 5 };
        var title = new Border { Background = Brush.Parse("#8E91D9"), Padding = new Thickness(8), BorderBrush = Brush.Parse("#C7C9FF"), BorderThickness = new Thickness(1) };
        title.Child = new TextBlock { Text = "PDCA-SENDER • 8 BARCODE", FontSize = 25, FontWeight = FontWeight.Bold, Foreground = Brush.Parse("#101126"), HorizontalAlignment = HorizontalAlignment.Center };
        root.Children.Add(title);

        var serverRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        serverRow.Children.Add(new TextBlock { Text = "Server IP", Width = 82, VerticalAlignment = VerticalAlignment.Center });
        ip.Width = 270; serverRow.Children.Add(ip);
        serverRow.Children.Add(new TextBlock { Text = "Port", Width = 45, VerticalAlignment = VerticalAlignment.Center });
        port.Width = 135; serverRow.Children.Add(port);
        var test = new Button { Content = "Test Connection", Width = 190, HorizontalAlignment = HorizontalAlignment.Right, Background = Brush.Parse("#BFC2F5"), Foreground = Brushes.Black, FontWeight = FontWeight.Bold };
        test.Click += async (_, _) => { try { using var c = new TcpClient(); await c.ConnectAsync(ip.Text!, int.Parse(port.Text!)); status.Text = "Connection OK"; } catch (Exception ex) { status.Text = "Connection failed: " + ex.Message; } };
        serverRow.Children.Add(test); root.Children.Add(serverRow);

        var queryRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
        queryRow.Children.Add(new TextBlock { Text = "Query Link", Width = 92, VerticalAlignment = VerticalAlignment.Center });
        url.HorizontalAlignment = HorizontalAlignment.Stretch; queryRow.Children.Add(url);
        queryRow.Children.Add(new TextBlock { Text = "Request Method", VerticalAlignment = VerticalAlignment.Center });
        method.Width = 115; queryRow.Children.Add(method);
        var save = new Button { Content = "Save Config", Background = Brush.Parse("#BFC2F5"), Foreground = Brushes.Black, FontWeight = FontWeight.Bold };
        save.Click += (_, _) => { try { Directory.CreateDirectory(Path.GetDirectoryName(configPath)!); File.WriteAllLines(configPath, new[] { "URL=" + url.Text, "IP=" + ip.Text, "PORT=" + port.Text }); status.Text = "Config saved."; } catch (Exception ex) { status.Text = "Save config failed: " + ex.Message; } };
        queryRow.Children.Add(save); root.Children.Add(queryRow);

        var inputRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
        inputRow.Children.Add(new TextBlock { Text = "SN Type", Width = 80, VerticalAlignment = VerticalAlignment.Center });
        var snType = new ComboBox { ItemsSource = new[] { "MLB SN", "PANEL SN", "JIG SN" }, SelectedIndex = 1, Width = 170, FontWeight = FontWeight.Bold, Background = Brush.Parse("#BFC2F5"), Foreground = Brushes.Black };
        inputRow.Children.Add(snType);
        inputRow.Children.Add(new TextBlock { Text = "Scan/Enter SN", VerticalAlignment = VerticalAlignment.Center });
        panel.Width = 350; inputRow.Children.Add(panel);
        var queryButton = new Button { Content = "Get Data", Width = 120, Background = Brush.Parse("#BFC2F5"), Foreground = Brushes.Black, FontWeight = FontWeight.Bold };
        queryButton.Click += async (_, _) => await QueryAsync(snType.SelectedItem?.ToString() ?? "PANEL SN"); inputRow.Children.Add(queryButton);
        var load = new Button { Content = "Load File", Width = 115, Background = Brush.Parse("#BFC2F5"), Foreground = Brushes.Black, FontWeight = FontWeight.Bold };
        load.Click += async (_, _) => await LoadFileAsync(); inputRow.Children.Add(load);
        inputRow.Children.Add(new TextBlock { Text = "● Manual   ◯ Auto", VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeight.Bold }); root.Children.Add(inputRow);

        var resultRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        resultRow.Children.Add(new TextBlock { Text = "Query Result", Width = 105, VerticalAlignment = VerticalAlignment.Center });
        raw.Height = 34; raw.HorizontalAlignment = HorizontalAlignment.Stretch; resultRow.Children.Add(raw); root.Children.Add(resultRow);

        var grid = new Grid { ColumnDefinitions = new ColumnDefinitions("1.05*,1.05*,0.9*,1.05*"), RowDefinitions = new RowDefinitions("Auto,Auto,Auto,Auto,Auto,Auto,Auto,Auto"), ColumnSpacing = 10, RowSpacing = 5 };
        for (int i = 0; i < 8; i++)
        {
            var result = new TextBox { Text = $"Barcode Data Result {i+1}", IsReadOnly = true, HorizontalContentAlignment = HorizontalAlignment.Center, VerticalContentAlignment = VerticalAlignment.Center, FontSize = 13, Background = Brush.Parse("#E7E5E0"), Foreground = Brush.Parse("#202020"), Height = 35 };
            Grid.SetRow(result, i); Grid.SetColumn(result, 0); grid.Children.Add(result);
            var gen = new Button { Content = $"Generate Barcode Data {i+1}", Tag = i, Height = 35, Background = Brush.Parse("#E7E5E0"), Foreground = Brush.Parse("#202020"), FontSize = 13 };
            gen.Click += (sender, args) => Generate((int)((Button)sender!).Tag!); Grid.SetRow(gen, i); Grid.SetColumn(gen, 1); grid.Children.Add(gen);
            var send = new Button { Content = $"SEND Barcode Data {i+1}", Tag = i, Height = 35, Background = Brush.Parse("#16872D"), Foreground = Brushes.White, FontWeight = FontWeight.Bold, FontSize = 13 };
            send.Click += async (sender, args) => await SendAsync((int)((Button)sender!).Tag!); Grid.SetRow(send, i); Grid.SetColumn(send, 2); grid.Children.Add(send);
            responses[i].Text = ""; responses[i].Watermark = $"Server Response data {i+1}"; responses[i].Height = 35; responses[i].FontSize = 13; responses[i].Background = Brush.Parse("#E7E5E0"); responses[i].Foreground = Brush.Parse("#202020");
            Grid.SetRow(responses[i], i); Grid.SetColumn(responses[i], 3); grid.Children.Add(responses[i]);
        }
        var gridBorder = new Border { BorderBrush = Brush.Parse("#BFC2F5"), BorderThickness = new Thickness(1), Padding = new Thickness(12), CornerRadius = new CornerRadius(4), Child = grid };
        root.Children.Add(gridBorder);
        var footer = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        status.Height = 28; status.Width = 500; status.Background = Brushes.Transparent; status.Foreground = Brushes.White;
        footer.Children.Add(status);
        footer.Children.Add(new TextBlock { Text = "Ignored duplicate data: 0", VerticalAlignment = VerticalAlignment.Center });
        footer.Children.Add(new TextBlock { Text = "Developed by SH", VerticalAlignment = VerticalAlignment.Center });
        root.Children.Add(footer);
        Content = new ScrollViewer { Content = root };
        LoadConfig();
    }
    void LoadConfig() { try { if (File.Exists(configPath)) foreach (var line in File.ReadAllLines(configPath)) { if (line.StartsWith("URL=")) url.Text = line[4..].Trim(); if (line.StartsWith("IP=")) ip.Text = line[3..].Trim(); if (line.StartsWith("PORT=")) port.Text = line[5..].Trim(); } } catch { } }
    async Task QueryAsync(string snType)
    {
        try {
            if (string.IsNullOrWhiteSpace(panel.Text)) { status.Text = "Enter Panel SN."; return; }
            var requestUrl = url.Text.Replace("{PANEL_SN}", Uri.EscapeDataString(panel.Text.Trim())).Replace("{PANEL}", Uri.EscapeDataString(panel.Text.Trim())).Replace("{JIGSN}", Uri.EscapeDataString(panel.Text.Trim()));
            using var req = new HttpRequestMessage((method.SelectedItem?.ToString() == "POST") ? HttpMethod.Post : HttpMethod.Get, requestUrl);
            if (req.Method == HttpMethod.Post) req.Content = new StringContent(string.Empty);
            using var response = await http.SendAsync(req); raw.Text = await response.Content.ReadAsStringAsync(); response.EnsureSuccessStatusCode();
            var found = Regex.Matches(raw.Text, @"[A-Za-z0-9][A-Za-z0-9._/-]{5,}").Cast<Match>().Select(m => m.Value).Distinct().Take(8).ToArray();
            for (int i=0;i<8;i++) { data[i].Text = i < found.Length ? found[i] : ""; }
            status.Text = $"Query completed. Parsed {found.Length} distinct values. Please verify results against the server's response format.";
        } catch (Exception ex) { status.Text = "Query failed: " + ex.Message; }
    }
    void Generate(int i) { try { var template = File.ReadAllText(templatePath); data[i].Text = template.Replace("{BARCODE}", data[i].Text).Replace("{PANEL_SN}", panel.Text); status.Text = $"Generated data {i+1}. Check template placeholders before sending."; } catch(Exception ex) { status.Text = "Template error: " + ex.Message; } }
    async Task SendAsync(int i) { try { using var c = new TcpClient { NoDelay = true }; await c.ConnectAsync(ip.Text!, int.Parse(port.Text!)); await using var stream = c.GetStream(); var bytes = Encoding.UTF8.GetBytes(data[i].Text ?? ""); await stream.WriteAsync(bytes); var buffer = new byte[8192]; using var cts = new CancellationTokenSource(2000); int n = await stream.ReadAsync(buffer, cts.Token); responses[i].Text = n == 0 ? "No response received." : Encoding.UTF8.GetString(buffer, 0, n); status.Text = $"Sent data {i+1}."; } catch (Exception ex) { responses[i].Text = "ERROR: " + ex.Message; status.Text = "TCP send failed."; } }
    async Task LoadFileAsync() { var files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = "Load serial numbers", AllowMultiple = false }); if (files.Count == 0) return; var lines = (await File.ReadAllTextAsync(files[0].Path.LocalPath)).Split(new[] { '\r', '\n', '\t', ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries).Distinct().ToArray(); for (int i=0;i<8;i++) data[i].Text = i < lines.Length ? lines[i] : ""; status.Text = $"Loaded {lines.Length} unique entries from {Path.GetFileName(files[0].Path.LocalPath)}."; }
}
