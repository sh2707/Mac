# PDCA Sender — Windows build / macOS offline run (migration starter)

## Enna irukku?
- `PDCA.Mac.csproj`, `MainWindow.cs`, `App.cs`, `Program.cs`: Avalonia cross-platform UI starter.
- `Services/`: original HTTP query and TCP service source retained for reference.
- `Config/`, `Templates/`: copied from the uploaded project.
- `Original-Windows-Source/`: uploaded Windows WPF source preserved unchanged.
- `BUILD_MAC_FROM_WINDOWS.bat`: Windows-la macOS ARM64 + Intel self-contained publish try pannum.
- `macOS/MAKE_APP_BUNDLE.sh`: publish folder Mac-ku copy pannina pin `.app` bundle create pannum.

## Windows-la build
1. Windows PC-la .NET 8 SDK install pannu.
2. First `BUILD_MAC_FROM_WINDOWS.bat` run pannumbodhu NuGet packages download panna internet thevai.
3. `publish/osx-arm64` = M1/M2/M3/M4 Mac mini. `publish/osx-x64` = Intel Mac mini.
4. Appropriate publish folder-ai Mac-ku USB/external drive moolama copy pannu.

## Mac-la offline use
1. Mac-la matching folder-ai `publish/osx-arm64` (or `publish/osx-x64`) path-la vechu `macOS/MAKE_APP_BUNDLE.sh` run pannalaam; alternatively publish folder executable-ai Terminal-la run pannalaam.
2. App runtime-ku internet/NuGet thevai illai; company barcode server/TCP endpoint reach aaganum endraal local company network access thevai.
3. macOS Gatekeeper/signing policies company device-la apply aagalam.

## Mukkiya limitation — production-ku munnaadi verify pannanum
Uploaded source is a Windows-only WPF `.NET Framework 4.8` app. WPF controls and `MainWindow.xaml.cs` event logic were **not** mechanically compatible with macOS. This package is a cross-platform migration starter, not a verified 1:1 port. It includes a basic Avalonia UI for query, file load, template generation, TCP send and response display, but it does **not yet guarantee** all original behaviours: exact 8-barcode parsing, MLB SN single-lane rules, manual/automatic batch modes, duplicate handling, detailed logging/status colours, saved settings, and the original UI layout need to be ported and tested against your real server/template. Query parsing is intentionally generic and must be validated; do not use it for production barcode sending until checked.

No original Windows source files were changed; the source is included under `Original-Windows-Source/` for comparison. This archive contains source/build scripts, not a prebuilt `.app` or tested binary. Building requires Windows with .NET SDK and first-time package restore access.
