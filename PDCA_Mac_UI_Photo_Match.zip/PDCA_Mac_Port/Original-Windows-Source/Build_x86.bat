@echo off
setlocal
set "ROOT=%~dp0"
set "MSBUILD=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" set "MSBUILD=%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" set "MSBUILD=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
if not exist "%MSBUILD%" set "MSBUILD=msbuild"
echo Building PDCA Sender in OFFLINE mode using locally installed .NET Framework 4.8 tools...
"%MSBUILD%" "%ROOT%PDCA Sender.csproj" /t:Build /p:Configuration=Release /p:Platform=x86 /p:RestoreIgnoreFailedSources=true /nologo
if errorlevel 1 (
  echo Build failed. Ensure Visual Studio Build Tools and .NET Framework 4.8 targeting pack are installed locally.
  pause
  exit /b 1
)
echo Build completed.
echo EXE: %ROOT%bin\x86\Release\PDCA Sender.exe
pause
