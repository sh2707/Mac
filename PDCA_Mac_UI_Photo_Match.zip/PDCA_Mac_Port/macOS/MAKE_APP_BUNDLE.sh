#!/bin/bash
set -euo pipefail
# Run on the target Mac after copying a published folder to this directory.
ARCH="$(uname -m)"
if [[ "$ARCH" == "arm64" ]]; then RID="osx-arm64"; else RID="osx-x64"; fi
SRC="$(cd "$(dirname "$0")/../publish/$RID" 2>/dev/null && pwd)" || { echo "Copy the Windows-built publish/$RID folder beside this script first."; exit 1; }
APP="PDCA Sender.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp -R "$SRC"/. "$APP/Contents/MacOS/"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>PDCA Sender</string>
<key>CFBundleDisplayName</key><string>PDCA Sender</string>
<key>CFBundleIdentifier</key><string>local.pdca.sender</string>
<key>CFBundleExecutable</key><string>PDCA-Sender</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1.0.0</string>
<key>CFBundleShortVersionString</key><string>1.0.0</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
</dict></plist>
PLIST
chmod +x "$APP/Contents/MacOS/PDCA-Sender"
echo "Created $APP. If macOS blocks it, review Gatekeeper policy; do not bypass company security controls."
